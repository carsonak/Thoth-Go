module thoth-go-exercise/01-hello-world

go 1.21
